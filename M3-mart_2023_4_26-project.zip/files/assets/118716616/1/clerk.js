var Clerk = pc.createScript('clerk');

Clerk.attributes.add('cameraDummy', {type: 'entity'});
Clerk.attributes.add('roboFace', {type: 'entity'});

Clerk.prototype.initialize = function() {
    this.entity.on('cursor:enter', this.onCursorEnter, this);
    this.entity.on('cursor:exit', this.onCursorExit, this);
    this.entity.on('cursor:click', this.onCursorClick, this);
};

Clerk.prototype.onCursorClick = function(e) {
    this.app.fire('moveWonderingEye', this.cameraDummy);
    this.app.fire('quest:clue');
};

Clerk.prototype.onCursorEnter = function() {
    document.body.style.cursor = 'pointer';
    this.roboFace.enabled = true;
};

Clerk.prototype.onCursorExit = function() {
    document.body.style.cursor = 'default';
    this.roboFace.enabled = false;
};