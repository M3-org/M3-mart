var ShortcutButton = pc.createScript('shortcutButton');

ShortcutButton.attributes.add('href', {type: 'string'});
ShortcutButton.attributes.add('target', {type: 'string', default: '_blank'});
ShortcutButton.attributes.add('trackNew', {type: 'boolean', default: false});
ShortcutButton.attributes.add('trackHotspot', {type: 'boolean', default: true});
ShortcutButton.attributes.add('trackOpenNewTab', {type: 'boolean', default: false});

ShortcutButton.prototype.initialize = function() {
    this.entity.on('cursor:enter', this.onCursorEnter, this);
    this.entity.on('cursor:exit', this.onCursorExit, this);
    this.entity.on('cursor:click', this.onCursorClick, this);
    this.newTabIcon = this.entity.parent.findByName('NewTabIcon');
    this.labelSlate = this.entity.parent.findByName('LabelSlate');
    this.newIconEntity = this.entity.parent.findByName('NewIcon');
    this.model = this.entity.parent.findByName('Icon').model;
    this.model.material = this.model.material.clone();
    this.originalColor = this.model.material.emissive.clone();

    if( this.trackHotspot ) {
        this.app.on('hotspot:report', function() {
            this.app.fire('hotspot:reporting', this.entity);
        }, this);
    }
};

ShortcutButton.prototype.postInitialize = function() {
    this.labelSlate.enabled = false;
    if( this.newIconEntity ) {
        this.newIconEntity.enabled = false;
    }
    if( this.newTabIcon ) {
        if( !this.trackOpenNewTab ) {
            this.newTabIcon.enabled = false;
        }
        else {
            this.newTabIcon.enabled = (this.target == '_blank');
        }
    }
};

ShortcutButton.prototype.onCursorClick = function() {
    if( false &&  this.target != '_self' && this.target != '_blank' ) {
        var iframe = document.querySelector('iframe[name="' + this.target + '"]');
        if( iframe.lastUrl != this.href ) {
            this.app.fire('interaction', {entity: this.entity, href: this.href, target: this.target});
        }

        iframe.lastUrl = this.href;
    }
    else {
        this.app.fire('interaction', {entity: this.entity, href: this.href, target: this.target});
    }

    this.app.fire('hud:openLink',{entity: this.entity, href: this.href, target: this.target});
    this.onCursorExit();
    //window.open(this.href, this.target);
};

ShortcutButton.prototype.onCursorEnter = function(e) {
    document.body.style.cursor = 'pointer';
    this.labelSlate.enabled = true;
    this.model.material.emissive = new pc.Color(255, 255, 255);
    this.model.material.update();

    var scoreData = localStorage.getItem('startpagescore');
    if( scoreData ) {
        scoreData = JSON.parse(scoreData);
    }
    else {
        scoreData = {usedUrls: []};
    }

    if( this.trackNew && this.newIconEntity ) {
        if( scoreData.usedUrls.indexOf(this.href) < 0 ) {
            this.newIconEntity.enabled = true;
        }
        else {
            this.newIconEntity.enabled = false;
        }
    }

    var dynamicLight = this.labelSlate.findByName('_dynamic_light');
    if( dynamicLight ) {
        this.worldDynamicLight.enabled = true;
        for( var x in this.worldDynamicLight.originalProperties ) {
            if( x == 'position' ) {
                var dpos = dynamicLight.getPosition();
                this.worldDynamicLight.setPosition(dpos.x, dpos.y, dpos.z);
            }
            else if( x == 'rotation' ) {
                var drot = dynamicLight.getRotation();
                this.worldDynamicLight.setRotation(drot.x, drot.y, drot.z, drot.w);
            }
            else {
                this.worldDynamicLight.light[x] = dynamicLight.light[x];
            }
        }
    }
};

ShortcutButton.prototype.onCursorExit = function(e) {
    document.body.style.cursor = 'default';
    this.labelSlate.enabled = false;
    this.model.material.emissive = new pc.Color(this.originalColor.r, this.originalColor.g, this.originalColor.b);
    this.model.material.update();

    var dynamicLight = this.labelSlate.findByName('_dynamic_light');
    if( dynamicLight ) {
        this.worldDynamicLight.enabled = false;
        for( var x in this.worldDynamicLight.originalProperties ) {
            if( x == 'position' ) {
                this.worldDynamicLight.setPosition(this.worldDynamicLight.originalProperties[x].x, this.worldDynamicLight.originalProperties[x].y, this.worldDynamicLight.originalProperties[x].z);
            }
            else if( x == 'rotation' ) {
                this.worldDynamicLight.setRotation(this.worldDynamicLight.originalProperties[x].x, this.worldDynamicLight.originalProperties[x].y, this.worldDynamicLight.originalProperties[x].z, this.worldDynamicLight.originalProperties[x].w);
            }
            else {
                this.worldDynamicLight.light[x] = this.worldDynamicLight.originalProperties[x];
            }
        }
    }
};
