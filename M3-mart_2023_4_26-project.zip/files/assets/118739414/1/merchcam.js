var Merchcam = pc.createScript('merchcam');
Merchcam.attributes.add('merchId', {type: 'string'}); // so that a different quest per-merchcam can be used. Defined in hudHTML.html
Merchcam.attributes.add('cameraDummy', {type: 'entity'});

Merchcam.prototype.initialize = function() {
    this.entity.on('cursor:enter', this.onCursorEnter, this);
    this.entity.on('cursor:exit', this.onCursorExit, this);
    this.entity.on('cursor:click', this.onCursorClick, this);
    this.mainCameraEntity = this.app.root.findByName('MainTarget');
    //this.app.on('moveWonderingEye', function() {
    //    console.log(arguments);
    //});
};

Merchcam.prototype.onCursorClick = function(e) {
    this.app.fire('moveWonderingEye', this.cameraDummy);
    if( this.merchId ) {
        this.app.fire('quest:clue', this.merchId);  // comment out this line if you don't want the camera change tied in w/ the quest system.
    }
    else {
        this.activateShelfCam();
    }
};

Merchcam.prototype.onCursorEnter = function() {
    document.body.style.cursor = 'pointer';
};

Merchcam.prototype.onCursorExit = function() {
    document.body.style.cursor = 'default';
};

Merchcam.prototype.activateShelfCam = function() {
    this.entity.collision.enabled = false;
    //console.log('do toggle cam logic');
    let self = this;
    let elem = this.uiElem;
    if( !elem ) {
        elem = document.createElement('div');
        elem.style.cssText = 'cursor: pointer; color: #fff; background-color: rgba(0, 0, 0, 0.8); position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%); border: 0; border-radius: 12px; padding: 16px; letter-spacing: 0.2em; font-size: 16px; font-weight: bold;';
        elem.innerHTML = 'GO BACK';
        elem.addEventListener('mousedown', function(e) {
            self.app.inputPaused = true;
            e.preventDefault();
            return true;
        });
        elem.addEventListener('mouseup', function(e) {
            self.deactivateShelfCam();
            setTimeout(function() {
                self.app.inputPaused = false;
            }, 100);
            elem.style.display = 'none';
            self.uiElem = null;
            elem.remove();
            //elem.parentNode.removeChild(elem);
        });
        document.body.appendChild(elem);
        this.uiElem = elem;
    }
};

Merchcam.prototype.deactivateShelfCam = function() {
    this.entity.collision.enabled = true;
    this.app.fire('moveWonderingEye', this.mainCameraEntity);
};