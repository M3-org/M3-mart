var ShortcutObject = pc.createScript('shortcutObject');

ShortcutObject.attributes.add('href', {type: 'string'});
ShortcutObject.attributes.add('target', {type: 'string', default: '_blank'});
ShortcutObject.attributes.add('title', {type: 'string', default: 'Untitled Shortcut'});
ShortcutObject.attributes.add('description', {type: 'string', default: 'Shortcut description.'});
ShortcutObject.attributes.add('screen', {type: 'string', default: ''});
ShortcutObject.attributes.add('screenAsset', {type: 'asset', assetType: 'texture'});
ShortcutObject.attributes.add('trackNew', {type: 'boolean', default: false});
ShortcutObject.attributes.add('trackHotspot', {type: 'boolean', default: true});
ShortcutObject.attributes.add('trackOpenNewTab', {type: 'boolean', default: false});


ShortcutObject.prototype.initialize = function() {
    this.entity.on('cursor:enter', this.onCursorEnter, this);
    this.entity.on('cursor:exit', this.onCursorExit, this);
    this.entity.on('cursor:click', this.onCursorClick, this);
    this.newTabIcon = this.entity.parent.findByName('NewTabIcon');
    this.highlightEntity = this.entity.parent.findByName('Highlight');
    this.newIconEntity = this.entity.parent.findByName('NewIcon');
    this.notHighlightEntity = this.entity.parent.findByName('NotHighlight');
    /*this.labelSlate = this.entity.parent.findByName('LabelSlate');
    this.model = this.entity.parent.findByName('Icon').model;
    this.model.material = this.model.material.clone();
    this.originalColor = this.model.material.emissive.clone();*/

    if( this.trackHotspot ) {
        this.app.on('hotspot:report', function() {
            this.app.fire('hotspot:reporting', this.entity);
        }, this);
    }


    this.worldDynamicLight = this.app.root.children[0].findByName('_dynamic_light');
    if( !this.worldDynamicLight.hasOwnProperty('originalProperties') ) {
        var originalProperties = {
            color: this.worldDynamicLight.light.color.clone(),
            intensity: this.worldDynamicLight.light.intensity,
            range: this.worldDynamicLight.light.range,
            innerConeAngle: this.worldDynamicLight.light.innerConeAngle,
            outerConeAngle: this.worldDynamicLight.light.outerConeAngle,
            position: this.worldDynamicLight.getPosition().clone(),
            rotation: this.worldDynamicLight.getRotation().clone()
        };
        this.worldDynamicLight.originalProperties = originalProperties;
    }
};

ShortcutObject.prototype.postInitialize = function() {
    if( this.highlightEntity ) {
        this.highlightEntity.enabled = false;
    }

    if( this.newIconEntity ) {
        this.newIconEntity.enabled = false;
    }
    if( this.newTabIcon ) {
        if( !this.trackOpenNewTab ) {
            this.newTabIcon.enabled = false;
        }
        else {
            this.newTabIcon.enabled = (this.target == '_blank');
        }
    }

    this.worldDynamicLight.enabled = false;
};

ShortcutObject.prototype.onCursorClick = function(e) {
    console.log(this.app.inputPaused);
    if( this.app.inputPaused ) {
        return;
    }

    if( false && this.target != '_self' && this.target != '_blank' ) {
        var iframe = document.querySelector('iframe[name="' + this.target + '"]');
        if( iframe.lastUrl != this.href ) {
            this.app.fire('interaction', {entity: this.entity, href: this.href, target: this.target});
        }

        iframe.lastUrl = this.href;
    }
    else {
        this.app.fire('interaction', {entity: this.entity, href: this.href, target: this.target});
    }

    var goodScreen = this.screen;
    if( !goodScreen && this.screenAsset) {
        goodScreen = this.screenAsset.getFileUrl();
    }
    this.app.fire('hud:openLink',{entity: this.entity, href: this.href, target: this.target, template: 'moreinfo', screen: goodScreen, description: this.description, title: this.title});
    this.onCursorExit();
    //window.open(this.href, this.target);
};

ShortcutObject.prototype.onCursorEnter = function() {
    document.body.style.cursor = 'pointer';
    if( this.notHighlightEntity ) {
        this.notHighlightEntity.enabled = false;
    }
    if( this.highlightEntity ) {
        this.highlightEntity.enabled = true;
    }

    var scoreData = localStorage.getItem('startpagescore');
    if( scoreData ) {
        scoreData = JSON.parse(scoreData);
    }
    else {
        scoreData = {usedUrls: []};
    }

    if( this.trackNew && this.newIconEntity ) {
        if( scoreData.usedUrls.indexOf(this.href) < 0 ) {
            this.newIconEntity.enabled = true;
        }
        else {
            this.newIconEntity.enabled = false;
        }
    }

    var dynamicLight = (this.highlightEntity) ? this.highlightEntity.findByName('_dynamic_light') : null;
    if( dynamicLight ) {
        this.worldDynamicLight.enabled = true;
        for( var x in this.worldDynamicLight.originalProperties ) {
            if( x == 'position' ) {
                var dpos = dynamicLight.getPosition();
                this.worldDynamicLight.setPosition(dpos.x, dpos.y, dpos.z);
            }
            else if( x == 'rotation' ) {
                var drot = dynamicLight.getRotation();
                this.worldDynamicLight.setRotation(drot.x, drot.y, drot.z, drot.w);
            }
            else {
                this.worldDynamicLight.light[x] = dynamicLight.light[x];
            }
        }
    }

    //this.labelSlate.enabled = true;
    //this.model.material.emissive = new pc.Color(255, 255, 255);
    //this.model.material.update();
};

ShortcutObject.prototype.onCursorExit = function() {
    document.body.style.cursor = 'default';
    if( this.highlightEntity ) {
        this.highlightEntity.enabled = false;
    }

    if( this.notHighlightEntity ) {
        this.notHighlightEntity.enabled = true;
    }
    //this.labelSlate.enabled = false;
    //this.model.material.emissive = new pc.Color(this.originalColor.r, this.originalColor.g, this.originalColor.b);
    //this.model.material.update();

    var dynamicLight = (this.highlightEntity) ? this.highlightEntity.findByName('_dynamic_light') : null;
    if( dynamicLight ) {
        this.worldDynamicLight.enabled = false;
        for( var x in this.worldDynamicLight.originalProperties ) {
            if( x == 'position' ) {
                this.worldDynamicLight.setPosition(this.worldDynamicLight.originalProperties[x].x, this.worldDynamicLight.originalProperties[x].y, this.worldDynamicLight.originalProperties[x].z);
            }
            else if( x == 'rotation' ) {
                this.worldDynamicLight.setRotation(this.worldDynamicLight.originalProperties[x].x, this.worldDynamicLight.originalProperties[x].y, this.worldDynamicLight.originalProperties[x].z, this.worldDynamicLight.originalProperties[x].w);
            }
            else {
                this.worldDynamicLight.light[x] = this.worldDynamicLight.originalProperties[x];
            }
        }
    }
};