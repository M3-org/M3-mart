var SelectionCursor = pc.createScript('selectionCursor');

SelectionCursor.attributes.add('cameraEntity', {type: 'entity'});

// initialize code called once per entity
SelectionCursor.prototype.initialize = function() {
    this.channelManagerEntity = this.app.root.findByName('ChannelManager');
    this.selectedMediaEntity = null;
    this.selectedMediaEntityCol = null;
    this.hoveredEntity = null;
    this.clickedEntity = null;
    this.app.mouse.on(pc.EVENT_MOUSEMOVE, this.onMouseMove, this);
    this.app.mouse.on(pc.EVENT_MOUSEDOWN, this.onMouseDown, this);
    this.app.mouse.on(pc.EVENT_MOUSEUP, this.onMouseUp, this);
    this.app.mouse.on(pc.EVENT_MOUSEWHEEL, this.onMouseWheel, this);
    this.app.on('touch:move', this.onTouchMove, this);

    this.app.inputPaused = false;
    this.app.on('pauseInput', this.onPauseInput, this);
    this.app.on('unpauseInput', this.onUnpauseInput, this);
    
    this.spawnModeEntity = null;
    var self = this;
    this.app.on('spawnMode:enter', function(spawnModeEntity) {
        self.spawnModeEntity = spawnModeEntity;
        
        // silently cancel out of any pending cursor interactions
        if( self.hoveredEntity ) {
            self.hoveredEntity = null;
        }
        if( self.clickedEntity ) {
            self.clickedEntity = null;
        }
    });
    this.app.on('spawnMode:exit', function() {
        self.spawnModeEntity = null;
    });
    
    this.app.keyboard.on(pc.EVENT_KEYUP, this.onKeyUp, this);
};

SelectionCursor.prototype.onPauseInput = function() {
    this.app.inputPaused = true;
    if( this.hoveredEntity ) {
        this.unhoverEntity(this.hoveredEntity);
        this.hoveredEntity = null;
    }
    if( this.clickedEntity ) {
        this.clickedEntity = null;
    }
};

SelectionCursor.prototype.onUnpauseInput = function() {
    this.app.inputPaused = false;
};

SelectionCursor.prototype.onKeyUp = function(e) {
  if( e.key === pc.KEY_DELETE )   {
      var parent = this.hoveredEntity.parent;
      if( parent ) {
          if( parent && parent.networkId ) {
              this.channelManagerEntity.script.channelManager.removeMediaObject(parent);

              // silently cancel out of cursor events
              this.hoveredEntity = null;
              this.clickedEntity = null;
              document.body.style.cursor = 'default';
          }
      }
  }
};

SelectionCursor.prototype.unhoverEntity = function(entity) {
    if( entity ) {
        if( entity.hasEvent('cursor:exit') ) {
            entity.fire('cursor:exit');
        }
    }
};

SelectionCursor.prototype.hoverEntity = function(entity) {
    if( entity ) {
        if( entity.hasEvent('cursor:enter') ) {
            entity.fire('cursor:enter');
        }
    }
};

SelectionCursor.prototype.cursorDownEntity = function(entity) {
    if( entity ) {
        if( entity.hasEvent('cursor:down') ) {
            entity.fire('cursor:down');
        }
    }
};

SelectionCursor.prototype.cursorUpEntity = function(entity) {
    if( entity ) {
        if( entity.hasEvent('cursor:up') ) {
            entity.fire('cursor:up');
        }
    }
};

SelectionCursor.prototype.cursorClickEntity = function(entity) {
    if( entity ) {
        if( entity.hasEvent('cursor:click') ) {
            entity.fire('cursor:click');
        }
    }
};

SelectionCursor.prototype.onMouseDown = function(e) {   
    if( this.app.inputPaused ) {
        return;
    }
     
    if( this.clickedEntity ) {
        this.clickedEntity = null;
    }
    
    if( this.hoveredEntity ) {
        this.cursorDownEntity(this.hoveredEntity);
        this.clickedEntity = this.hoveredEntity;
    }
    
    this.app.fire('cursor:down:global', this.clickedEntity);
};

SelectionCursor.prototype.onMouseUp = function(e) {   
    if( this.app.inputPaused ) {
        return;
    }
     
    var wasClickedEntity = null;
    if( this.clickedEntity ) {
        if( this.clickedEntity == this.hoveredEntity ) {
            wasClickedEntity = this.clickedEntity;
        }
        
        this.clickedEntity = null;
    }
    
    if( this.hoveredEntity ) {
        this.cursorUpEntity(this.hoveredEntity);
    }
    
    if( wasClickedEntity ) {
        this.cursorClickEntity(wasClickedEntity);
    }
    this.app.fire('cursor:up:global', this.hoveredEntity);
};

SelectionCursor.prototype.onTouchMove = function(opts) {
    this.onMouseMove(opts.screen);
};

SelectionCursor.prototype.onMouseMove = function(e) {
    var result = this.doRaycast({x: e.x, y: e.y});
    var entity = (result && result.entity) ? result.entity : null;
    
    if( !this.app.inputPaused ) {
        if( !entity ) {
            if( this.hoveredEntity ) {
                this.unhoverEntity(this.hoveredEntity);
                this.hoveredEntity = null;
            }
            if( this.clickedEntity ) {
                this.clickedEntity = null;
            }
        }
        else {
            if( this.hoveredEntity ) {
                if( this.hoveredEntity == entity ) {
                    // send cursormove event.
                }
                else {
                    this.unhoverEntity(this.hoveredEntity);
                    this.hoveredEntity = null;
                    
                    this.hoveredEntity = entity;
                    this.hoverEntity(entity);
                }
            }
            else {
                this.hoveredEntity = entity;
                this.hoverEntity(entity);
            }
            
            if( this.clickedEntity && this.clickedEntity != entity ) {
                this.clickedEntity = null;
            }
        }
    }
    this.app.lastCursorMove = {raycast: result, screen: {x: e.x, y: e.y}};
    this.app.fire('cursor:move:global', {raycast: result, screen: {x: e.x, y: e.y}});
};

SelectionCursor.prototype.doRaycast = function(screenPosition) {
    var from = this.cameraEntity.getPosition();
    var to = this.cameraEntity.camera.screenToWorld(screenPosition.x, screenPosition.y, this.cameraEntity.camera.farClip);
    var result;
    if( !this.spawnModeEntity ) {
        result = this.app.systems.rigidbody.raycastFirst(from, to);
    }
    else {
        // do NOT cast against UI elements if we are in spawn mode.
        result = this.app.systems.rigidbody.raycastFirstWithoutTag(from, to, 'ui');
    }
    
    if (result) {
        return result;
    }
    return null;
};

SelectionCursor.prototype.onMouseWheel = function(e) {
    this.app.fire('cursor:wheel:global', e.wheelDelta, this);
};

SelectionCursor.prototype.update = function(dt) {
    
};