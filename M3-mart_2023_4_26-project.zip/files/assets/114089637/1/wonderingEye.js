var WonderingEye = pc.createScript('wonderingEye');

WonderingEye.attributes.add('camera', {type: 'entity'});
WonderingEye.attributes.add('cameraRig', {type: 'entity'});

// initialize code called once per entity
WonderingEye.prototype.initialize = function() {
    //this.app.mouse.on(pc.EVENT_MOUSEMOVE, this.onMouseMove, this);
    //this.app.on('touch:move', this.onMouseMove, this);
    this.app.on('cursor:move:global', this.onCursorMoveGlobal, this);
    this.app.on('cursor:wheel:global', this.onCursorWheelGlobal, this);
    this.app.on('moveWonderingEye', this.onMoveWonderingEye, this);
    this.app.on('resetWonderingEye', this.onResetWonderingEye, this);
    //this.app.mouse.on(pc.EVENT_MOUSEWHEEL, this.onMouseWheel, this);
    this.originalRotation = this.camera.getRotation().clone();//this.cameraRig.getRotation().clone();
    this.originalPosition = this.camera.getPosition().clone();//this.cameraRig.getPosition().clone();
    this.originalLocalCameraRotation = this.camera.getLocalRotation().clone();  // note this.entity and this.camera are the same thing. :D
    this.originalEulers = this.entity.getEulerAngles();
    this.rotation = new pc.Quat();
    this.targetRotation = new pc.Quat();
    this.originRotation = new pc.Quat();
    this.lerpDuration = 0.5;
    this.lerpActive = false;
};

WonderingEye.prototype.onMoveWonderingEye = function(cameraDummy) {
    this.camera.setPosition(cameraDummy.getPosition().clone());  // is clone needed??
    this.camera.setRotation(cameraDummy.getRotation().clone());  //''
    //this.camera.setLocalEulerAngles(0, 0, 0);
    this.camera.setLocalRotation(this.originalLocalCameraRotation);
    this.originalEulers = this.camera.getEulerAngles();
    this.rotation = new pc.Quat();
    this.targetRotation = new pc.Quat();
    this.originRotation = new pc.Quat();
    this.lerpDuration = 0.5;
    this.lerpActive = false;
};

WonderingEye.prototype.onResetWonderingEye = function() {
    this.camera.setPosition(this.originalPosition);
    this.camera.setRotation(this.originRotation);
    this.camera.setLocalRotation(this.originalLocalCameraRotation);
    //this.camera.setLocalEulerAngles(0, 0, 0);
    this.originalEulers = this.camera.getEulerAngles();
    this.rotation = new pc.Quat();
    this.targetRotation = new pc.Quat();
    this.originRotation = new pc.Quat();
    this.lerpDuration = 0.5;
    this.lerpActive = false;
};

WonderingEye.prototype.postInitialize = function() {
    if( this.app.qualitySettings.preset == 'low' ) {
        this.camera.camera.fov = 80;
    }
};

//WonderingEye.prototype.onMouseMove = function(e) {
WonderingEye.prototype.onCursorMoveGlobal = function(opts) {
    if( false && this.app.inputPaused ) {
        return;
    }

    var horizontal = opts.screen.x / window.innerWidth;
    var vertical = opts.screen.y / window.innerHeight;
    //if( e.hasOwnProperty('startX') ) {
        // TODO: Make it kind of slide in the direction you are pulling.
        // The further you pull from where you 1st touched, the faster the camera tries to spin that direction.
        //console.log("TODO: Add touch support!");
    //}
    var factorHorizontal = (horizontal - 0.5);
    var factorVertical = (vertical - 0.5);
    var maxLookHorizontal = 20 * 3;
    var maxLookVertical = 3 * 4;
    //this.camera.setLocalEulerAngles((-maxLookVertical * factorVertical)-3, -maxLookHorizontal * factorHorizontal, 0);
    
    // setup a new lerp
    var temp = this.entity.getRotation();
    this.originRotation.set(temp.x, temp.y, temp.z, temp.w);
    this.targetRotation.setFromEulerAngles(this.originalEulers.x + ((-maxLookVertical * factorVertical)-3), this.originalEulers.y + (-maxLookHorizontal * factorHorizontal), 0);
    this.lerpElapsed = 0;
    this.lerpActive = true;
};

WonderingEye.prototype.onCursorWheelGlobal = function(delta) {
    this.onMouseWheel({wheelDelta: delta});
};

WonderingEye.prototype.onMouseWheel = function(e) {
    if( this.app.inputPaused ) {
        return;
    }
    
    var fovMax = 90;
    var fovMin = 40;
    var delta = e.wheelDelta;
    var fov = this.camera.camera.fov;
    if( delta > 0 ) {
        if( fov + 1 <= fovMax ) {
            fov += 1;
        }
    }
    else {
        if( fov - 1 >= fovMin ) {
            fov -= 1;
        }
    }
    this.camera.camera.fov = fov;
};

WonderingEye.prototype.update = function(dt) {
    if( this.lerpActive ) {
        this.lerpElapsed += dt;
        var amount = this.lerpElapsed / this.lerpDuration;
        if( amount >= 1 ) {
            amount = 1;
            this.lerpActive = false;
        }
        
        this.rotation.slerp(this.originRotation, this.targetRotation, amount);
        this.camera.setRotation(this.rotation.x, this.rotation.y, this.rotation.z, this.rotation.w);
    }
};