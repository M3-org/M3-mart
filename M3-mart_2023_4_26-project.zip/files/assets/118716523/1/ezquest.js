var Ezquest = pc.createScript('ezquest');

Ezquest.attributes.add('cluecornerasset', {type: 'asset', assetType: 'texture'});
Ezquest.attributes.add('dialogueiconasset', {type: 'asset', assetType: 'texture'});

function loadAJavaScript(fileName) {
    console.log('loading javascript: ' + fileName);
    return new Promise(function(resolve, reject) {
        var elem = document.createElement("script");
        elem.type = "text/javascript";
        elem.src = fileName;

        elem.addEventListener("load", resolve);

        // We are added to the head so loading will begin immediately & asynchronously
        document.getElementsByTagName("head")[0].appendChild(elem);
    });
}

Ezquest.prototype.initialize = function() {
    this.div = null;
    this.app.on('quest:clue', this.onQuestClue, this);
};

Ezquest.prototype.onQuestClue = function() {
    this.createQuestDialogue();
};

Ezquest.prototype.destroyQuestDialogue = function() {
    this.div.remove();
    this.div = null;
    this.app.fire('unpauseInput');
};

Ezquest.prototype.createQuestDialogue = function() {
    this.app.fire('pauseInput');
    var self = this;
    var ezquestContainer = document.body.querySelector('.ezquestContainerHTML');
    var ezquestContainerHTMLText = ezquestContainer.value;
    var clueCornerUrl = this.cluecornerasset.getFileUrl();
    ezquestContainerHTMLText = ezquestContainerHTMLText.replace(/ASSETURL_cluecorner/g, clueCornerUrl);
    this.div = document.createElement('div');
    this.div.className = 'ezquestContainer';
    this.div.innerHTML = ezquestContainerHTMLText;
    document.body.appendChild(this.div);

    var arcadeHud = {
        generateIconHTML: function(fileName, width, height, obsoleteColorValueName) {
            return '<img src="' + fileName + '" style="width: ' + width + 'px; height: ' + height + 'px;" />';
        }
    };

    var rawquest = {
        "id": "testQuestId",
        "_template": "gossip",
        "title": "Test Quest Title",
        "objective": "Talk to the clerk.",
        "dialogue": "",
        "spin": "0",
        //"object": "-s4VXNczhP9FGrHk13PF",
        "type": 1,//"comic",
        "interact": "useRepeatable",
        "presence": "always",
        "visibility": "untilSuccess",
        "initial": "active"
    };

    var merchQuestId = 'testmerch';
    if( merchQuestId ) {
        rawquest.dialogue = document.querySelector('#' + merchQuestId).value;
    }
    else {
        rawquest.dialogue = document.querySelector('#testQuestText').value;
    }

    var lastSpokenText = "Hello World.";



    //var questId = arcadeHud.getParameterByName("quest");
    var questId = 'testQuestId';
    //var questClueId = arcadeHud.getParameterByName("id");
    var questClueId = 'testClueId';
    //var questClue = aaapi.cmdEx("getQuestClue", questClueId);
    var questClue = rawquest;
    var unparsedDialogue = questClue.dialogue;//arcadeHud.getParameterByName("dialogue");

    var comicCornerElem = this.div.querySelector('#comicCorner');
    if( questClue.type == 1 )
        comicCornerElem.style.display = 'block';

    // Parse the dialogue into a dialogue object.
    function parseRawDialogue(rawDialogue)
    {
        function findFirstNotOf(text, character)
        {
            for (var i = 0; i < text.length; i++)
            {
                if( text[i] != character )
                    return i;
            }
            return -1;
        }

        function getTextActions(line)
        {
            var actionRegex = /(\[[^\]]+\])+\r?$/g;
            var actionResults = line.match(actionRegex);

            if( !actionResults )
                actionResults = [];
            else if( Array.isArray(actionResults) && actionResults.length > 0 )
            {
                var braceRegex = /[\[\]]+/;
                actionResults = actionResults[0].split(braceRegex).filter(function(e) { return e; });
            }

            var validActions = ["exit", "success", "failure", "jump", "jump2", "jump3", "jumplite", "jumplite2", "jumplite3", "menu", "menu2", "menu3"];
            // only keep the actions down to the 1st invalid one found.
            // TODO: Reverse direction of the array.
            actionResults.reverse();
            
            for( var j = 0; j < actionResults.length; j++ )
            {
                if( validActions.indexOf(actionResults[j]) < 0 )
                {
                    actionResults.splice(j);
                    break;
                }
            }
            actionResults.reverse();

            /*for( var j = actionResults.length-1; j >= 0; j-- )
            {
                if( validActions.indexOf(actionResults[j]) < 0 )
                {
                    if( actionResults.length > j+1 )
                        console.log(JSON.stringify(actionResults.splice(j+1)));
                    else
                        actionResults = [];
                    break;
                }
            }*/

            return actionResults;
        }

        function composeResult(numLines, quest_text, actions, response_text, responses)
        {
            var dialogue = {};
            if( quest_text.length > 0 )
                dialogue.quest_text = quest_text;
            if( actions.length > 0 )
                dialogue.quest_action = actions;
            if( response_text != "" )
                dialogue.response_text = response_text;
            if( responses.length > 0 )
                dialogue.responses = responses;

            return {numLines: numLines, dialogue: dialogue};
        }

        // Cannot be empty...
        if(rawDialogue == "")
        {
            console.log("Parsing Error: Dialogue cannot be empty.");
            return;
        }

        // Break into lines.
        var dialogueLines = rawDialogue.match(/[^\r\n]+/g);
        if( dialogueLines.length == 0 )
        {
            console.log("Parsing Error: Dialogue cannot be empty.");
            return;
        }

        var depthChar = "\t";

        // Starts with QUEST line
        // (in other words, it does NOT start with TAB.)
        if( dialogueLines[0][0] == depthChar )
        {
            console.log("Parsing Error: Dialogue cannot start with a TAB character.");
            return;
        }

        // START RECURSIVE STUFF HERE
        function parseDialogueBlock(blockStartLine)
        {
            // Blocks may have a response_text, quest_text, response_action, quest_action, and an array of responses.

            if( blockStartLine >= dialogueLines.length )
            {
                return {numLines: 0, dialogue: {}};
            }

            var blockDepth = findFirstNotOf(dialogueLines[blockStartLine], depthChar);

            // Alright. Now start filling up a quest_text array of successive QUEST lines.
            var quest_text = [];
            var quest_action = [];
            var responses = [];
            var i;
            var oldActions;
            for( i = blockStartLine; i < dialogueLines.length; i++ )
            {
                var response_action = [];
                var response_text = "";

                var line = dialogueLines[i];

                var depth = findFirstNotOf(line, depthChar);
                var deltaDepth = depth - blockDepth;
                var isResponseLine = (depth % 2 == 1);
                var isQuestLine = !isResponseLine;

                //console.log(isQuestLine + "Line #" + i + " (depth: " + depth + " | " + deltaDepth + "): " + line);

                // check for actions on EVERY line. (Even though we only want to use actions that are on the LAST line.)
                var oldActions = actions;
                var actions = getTextActions(line);
                //console.log(line + " : " + JSON.stringify(actions));
                if( actions.length > 0 )
                {
                    // cull them off the end of the line.
                    var lastNonActionCharIndex = line.length;
                    for( var j = 0; j < actions.length; j++ )
                        lastNonActionCharIndex -= actions[j].length+2;
                    line = line.substring(0, lastNonActionCharIndex);
                }

                if( deltaDepth == 0 )
                {
                    if( isResponseLine )
                    {
                        var numLines = i - blockStartLine;
                        var dialogueResultInfo = composeResult(numLines, quest_text, quest_action, response_text, responses);
                        return dialogueResultInfo;
                    }

                    if( isQuestLine )
                    {
                        quest_text.push(line.trim());
                    }
                }
                else if( deltaDepth > 0 )
                {
                    var dialogueResultInfo = parseDialogueBlock(i+1);
                    // {dialogue: dialogue, numLines: N}

                    i += dialogueResultInfo.numLines;

                    if( isResponseLine )
                    {
                        dialogueResultInfo.dialogue.response_text = line.trim();
                        if( actions.length > 0 )
                            dialogueResultInfo.dialogue.response_action = actions;

                        responses.push(dialogueResultInfo.dialogue);
                        actions = [];
                    }
                }
                else if( deltaDepth < 0 )
                {
                    var numLines = i - blockStartLine;
                    var dialogueResultInfo = composeResult(numLines, quest_text, oldActions, response_text, responses);
                    return dialogueResultInfo;
                }
            }

            var numLines = i - blockStartLine;
            var dialogueResultInfo = composeResult(numLines, quest_text, actions, response_text, responses);
            return dialogueResultInfo;
        }

        var fullDialogueResultInfo = parseDialogueBlock(0);
        var fullDialogue = fullDialogueResultInfo.dialogue;
        console.log(fullDialogue);
        return fullDialogue;
    }

    // process dialogues and add in branch_parent references.
    function processDialogueTree(dialogue, branchParent, branchGrandparent, branchGreatgrandparent, branchGreatgreatgrandparent)
    {
        // add our branch parent & grandparent references, even if they are undefined.
        dialogue.branch_parent = branchParent;
        dialogue.branch_grandparent = branchGrandparent;
        dialogue.branch_greatgrandparent = branchGreatgrandparent;
        dialogue.branch_greatgreatgrandparent = branchGreatgreatgrandparent;

        // set our next branch parent, IF we are a new one.
        // ONLY if a dialogue has MULTIPLE responses is it a new branch parent.
        var nextBranchParent = branchParent;
        var nextBranchGrandparent = branchGrandparent;
        var nextBranchGreatgrandparent = branchGreatgrandparent;
        var nextBranchGreatgreatgrandparent = branchGreatgreatgrandparent;
        if( dialogue.hasOwnProperty('responses') )
        {
            if( dialogue.responses.length > 1 )
            {
                nextBranchGreatgreatgrandparent = nextBranchGreatgrandparent;
                nextBranchGreatgrandparent = nextBranchGrandparent;
                nextBranchGrandparent = nextBranchParent;
                nextBranchParent = dialogue;
            }

            for( var i = 0; i < dialogue.responses.length; i++ )
            {
                processDialogueTree(dialogue.responses[i], nextBranchParent, nextBranchGrandparent, nextBranchGreatgrandparent, nextBranchGreatgreatgrandparent);
            }
        }
    }

    // we have multiple test dialogues, so gotta process each one.
    //for( var i = 0; i < dialogues.length; i++ )
    //{
    //	processDialogueTree(dialogues[i]);
    //}

    var g_activeDialogue;
    var g_activeQuestTextIndex;

    var questDialogueElem = document.querySelector("#questDialogue");
    var interactIconElem = document.querySelector("#interactIcon");
    var interactButtonElem = document.querySelector('#interactButton');
    var questResponsesLeftElem = document.querySelector("#questResponsesLeft");
    var questResponsesRightElem = document.querySelector("#questResponsesRight");

    function doDialogueSuccess()
    {
        console.log("win event!");
        //aaapi.cmd('questDialogueEvent', questId, questClueId, 'success');
    }

    function doDialogueFailure()
    {
        console.log("fail event. :(");
        aaapi.cmd('questDialogueEvent', questId, questClueId, 'failure');
    }

    function exitDialogue()
    {
        //console.log('exit dialogue!');
        //aaapi.cmd('deactivateInputMode');
        self.destroyQuestDialogue();
        self.app.fire('resetWonderingEye');
    }

    interactButtonElem.addEventListener('click', function()
    {
        if( g_activeDialogue.quest_text.length > g_activeQuestTextIndex+1 )
        {
            g_activeQuestTextIndex++;
            showQuestDialogue(g_activeDialogue, g_activeQuestTextIndex);
        }
        else if( this.hasOwnProperty('action') )
        {
            // mutually exclusive actions: JUMP, EXIT, SUCCESS, FAILURE
            if( this.action.indexOf('success') >= 0 )
            {
                doDialogueSuccess();
                exitDialogue();
            }
            else if( this.action.indexOf('failure') >= 0 )
            {
                doDialogueFailure();
                exitDialogue();
            }
            else if( this.action.indexOf('jump') >= 0 )
            {
                showQuestDialogue(g_activeDialogue.branch_parent, 0);
            }
            else if( this.action.indexOf('jump2') >= 0 )
            {
                showQuestDialogue(g_activeDialogue.branch_grandparent, 0);
            }
            else if( this.action.indexOf('jump3') >= 0 )
            {
                showQuestDialogue(g_activeDialogue.branch_greatgrandparent, 0);
            }
            else if( this.action.indexOf('jumplite') >= 0 )
            {
                var targetLine = (g_activeDialogue.branch_parent.quest_text.length > 0) ? g_activeDialogue.branch_parent.quest_text.length-1 : 0;
                showQuestDialogue(g_activeDialogue.branch_parent, targetLine);
            }
            else if( this.action.indexOf('jumplite2') >= 0 )
            {
                var targetLine = (g_activeDialogue.branch_grandparent.quest_text.length > 0) ? g_activeDialogue.branch_grandparent.quest_text.length-1 : 0;
                showQuestDialogue(g_activeDialogue.branch_grandparent, targetLine);
            }
            else if( this.action.indexOf('jumplite3') >= 0 )
            {
                var targetLine = (g_activeDialogue.branch_greatgrandparent.quest_text.length > 0) ? g_activeDialogue.branch_greatgrandparent.quest_text.length-1 : 0;
                showQuestDialogue(g_activeDialogue.branch_greatgrandparent, targetLine);
            }
            else if( this.action.indexOf('menu3') >= 0 )
            {
                if( g_activeDialogue.branch_greatgrandparent.hasOwnProperty('responses') && g_activeDialogue.branch_greatgrandparent.responses.length > 0 )
                {
                    var goodLineIndex = g_activeDialogue.branch_greatgrandparent.quest_text.length-1;
                    updateResponses(g_activeDialogue.branch_greatgrandparent, goodLineIndex);
                    g_activeDialogue = g_activeDialogue.branch_greatgrandparent;
                    g_activeQuestTextIndex = goodLineIndex;
                }
                else
                {
                    // do nothing.  illogical to do this action if the parent has no responses.
                }
            }
            else if( this.action.indexOf('menu2') >= 0 )
            {
                if( g_activeDialogue.branch_grandparent.hasOwnProperty('responses') && g_activeDialogue.branch_grandparent.responses.length > 0 )
                {
                    var goodLineIndex = g_activeDialogue.branch_grandparent.quest_text.length-1;
                    updateResponses(g_activeDialogue.branch_grandparent, goodLineIndex);
                    g_activeDialogue = g_activeDialogue.branch_grandparent;
                    g_activeQuestTextIndex = goodLineIndex;
                }
                else
                {
                    // do nothing.  illogical to do this action if the parent has no responses.
                }
            }
            else if( this.action.indexOf('menu') >= 0 )
            {
                if( g_activeDialogue.branch_parent.hasOwnProperty('responses') && g_activeDialogue.branch_parent.responses.length > 0 )
                {
                    var goodLineIndex = g_activeDialogue.branch_parent.quest_text.length-1;
                    updateResponses(g_activeDialogue.branch_parent, goodLineIndex);
                    g_activeDialogue = g_activeDialogue.branch_parent;
                    g_activeQuestTextIndex = goodLineIndex;
                }
                else
                {
                    // do nothing.  illogical to do this action if the parent has no responses.
                }
            }
            else if( this.action.indexOf('exit') >= 0 )
            {
                exitDialogue();
            }
        }
        else
        {
            console.log("Unhandled quest response.");

            // quit the dialogue, for now.
            exitDialogue();
        }
    });

    // get tis object
    /*var object = (questClue.objectId != '') ? aaapi.cmdEx('getObject', questClue.objectId) : null;
    var model = (!!object && !!object.model && object.model != '') ? aaapi.cmdEx('getLibraryModel', object.model) : null;
    var modelFile = (!!model) ? model.platforms[arcadeHud.platformId].file : "";

    function getVoiceForModel()
    {
        if( ttsModelVoices.hasOwnProperty(modelFile) )
            return ttsModelVoices[modelFile];
        else
            return ttsModelVoices.default;
    }

    var voiceForModel = getVoiceForModel();
    ttsVoiceElem.value = voiceForModel.voice;
    ttsPitchElem.value = voiceForModel.pitch;
    ttsRateElem.value = voiceForModel.rate;
    ttsVolumeElem.value = voiceForModel.volume;*/

    // fill our responses.
    function addQuestResponse(sideElem, response)
    {
        var responseElem = document.createElement('div');
        responseElem.className = 'questResponse';
        
        // set some things up for jumping back up a dialogue level.
        //response.jump1 = jump1;
        //response.jump2 = jump2;

        responseElem.dialogue = response;
        responseElem.addEventListener('click', function()
        {
            // check for RESPONSE ACTIONS, that happen when user clicks a response.
            if( this.dialogue.hasOwnProperty('response_action') )
            {
                if( this.dialogue.response_action.indexOf('success') >= 0 )
                    doDialogueSuccess();
                else if( this.dialogue.response_action.indexOf('failure') >= 0 )
                    doDialogueFailure();
                else if( this.dialogue.response_action.indexOf('jump') >= 0 )
                    showQuestDialogue(this.dialogue.branch_parent, 0);
                else if( this.dialogue.response_action.indexOf('jump2') >= 0 )
                    showQuestDialogue(this.dialogue.branch_grandparent, 0);
                else if( this.dialogue.response_action.indexOf('jump3') >= 0 )
                    showQuestDialogue(this.dialogue.branch_greatgrandparent, 0);
                else if( this.dialogue.response_action.indexOf('jumplite') >= 0 )
                {
                    var targetLine = (this.dialogue.branch_grandparent.quest_text.length > 0) ? this.dialogue.branch_grandparent.quest_text.length-1 : 0;
                    showQuestDialogue(this.dialogue.branch_grandparent, targetLine);
                }
                else if( this.dialogue.response_action.indexOf('jumplite2') >= 0 )
                {
                    var targetLine = (this.dialogue.branch_greatgrandparent.quest_text.length > 0) ? this.dialogue.branch_greatgrandparent.quest_text.length-1 : 0;
                    showQuestDialogue(this.dialogue.branch_greatgrandparent, targetLine);
                }
                else if( this.dialogue.response_action.indexOf('jumplite3') >= 0 )
                {
                    var targetLine = (this.dialogue.branch_greatgreatgrandparent.quest_text.length > 0) ? this.dialogue.branch_greatgreatgrandparent.quest_text.length-1 : 0;
                    showQuestDialogue(this.dialogue.branch_greatgreatgrandparent, targetLine);
                }
                else if( this.dialogue.response_action.indexOf('menu3') >= 0 )
                {

                    if( this.dialogue.branch_greatgrandparent.hasOwnProperty('responses') && this.dialogue.branch_greatgrandparent.responses.length > 0 )
                    {
                        var goodLineIndex = this.dialogue.branch_greatgrandparent.quest_text.length-1;
                        updateResponses(this.dialogue.branch_greatgrandparent, goodLineIndex);
                        g_activeDialogue = this.dialogue.branch_greatgrandparent;
                        g_activeQuestTextIndex = goodLineIndex;
                    }
                    else
                    {
                        // do nothing.  illogical to do this action if the greatgrandparent has no responses.
                    }
                }
                else if( this.dialogue.response_action.indexOf('menu2') >= 0 )
                {

                    if( this.dialogue.branch_grandparent.hasOwnProperty('responses') && this.dialogue.branch_grandparent.responses.length > 0 )
                    {
                        var goodLineIndex = this.dialogue.branch_grandparent.quest_text.length-1;
                        updateResponses(this.dialogue.branch_grandparent, goodLineIndex);
                        g_activeDialogue = this.dialogue.branch_grandparent;
                        g_activeQuestTextIndex = goodLineIndex;
                    }
                    else
                    {
                        // do nothing.  illogical to do this action if the grandparent has no responses.
                    }
                }
                else if( this.dialogue.response_action.indexOf('menu') >= 0 )
                {

                    if( this.dialogue.branch_parent.hasOwnProperty('responses') && this.dialogue.branch_parent.responses.length > 0 )
                    {
                        var goodLineIndex = this.dialogue.branch_parent.quest_text.length-1;
                        updateResponses(this.dialogue.branch_parent, goodLineIndex);
                        g_activeDialogue = this.dialogue.branch_parent;
                        g_activeQuestTextIndex = goodLineIndex;
                    }
                    else
                    {
                        // do nothing.  illogical to do this action if the parent has no responses.
                    }
                }
                else if( this.dialogue.response_action.indexOf('exit') >= 0 )
                    exitDialogue();
            }

            //if( (!this.dialogue.hasOwnProperty('responses') || this.dialogue.responses.length == 0) )
            //	console.log("Need to end it?");

            if( !!this.dialogue && this.dialogue.hasOwnProperty('quest_text'))
                showQuestDialogue(this.dialogue, 0);
            else if( !this.dialogue.hasOwnProperty('response_action') || (this.dialogue.response_action.indexOf("exit") < 0 && this.dialogue.response_action.indexOf("jump") < 0 && this.dialogue.response_action.indexOf("jump2") < 0 && this.dialogue.response_action.indexOf("jump3") < 0 && this.dialogue.response_action.indexOf("jumplite") && this.dialogue.response_action.indexOf("jumplite2") < 0 && this.dialogue.response_action.indexOf("jumplite3") < 0 && this.dialogue.response_action.indexOf("menu") < 0 && this.dialogue.response_action.indexOf("menu2") < 0 && this.dialogue.response_action.indexOf("menu3") < 0) )
            {
                // If this is a mal-formed ending to a dialogue, make it well-formed.
                exitDialogue();
            }
        }.bind(responseElem));
        responseElem.appendChild(document.createTextNode(response.response_text));
        sideElem.appendChild(responseElem);
    }

    function updateResponses(dialogue, questTextIndex)
    {
        delete interactButtonElem.action;

        // if this dialogue line is just going to 'menu' action anyways, show the menu NOW so that the player doesn't even need to click OK.
        if( dialogue.quest_text.length == questTextIndex+1 && dialogue.hasOwnProperty('quest_action') && dialogue.quest_action.indexOf('menu') >= 0 && !!dialogue.branch_parent && dialogue.branch_parent.responses.length > 0 && !!dialogue.branch_parent.quest_text && dialogue.branch_parent.quest_text.length > 0 )
        {
            var goodLineIndex = dialogue.branch_parent.quest_text.length-1;
            updateResponses(dialogue.branch_parent, goodLineIndex);
            return;
        }

        // same as above, but for 'menu2' action.
        if( dialogue.quest_text.length == questTextIndex+1 && dialogue.hasOwnProperty('quest_action') && dialogue.quest_action.indexOf('menu2') >= 0 && !!dialogue.branch_grandparent && dialogue.branch_grandparent.responses.length > 0 && !!dialogue.branch_grandparent.quest_text && dialogue.branch_grandparent.quest_text.length > 0 )
        {
            var goodLineIndex = dialogue.branch_grandparent.quest_text.length-1;
            updateResponses(dialogue.branch_grandparent, goodLineIndex);
            return;
        }

        // same as above, but for 'menu3' action.
        if( dialogue.quest_text.length == questTextIndex+1 && dialogue.hasOwnProperty('quest_action') && dialogue.quest_action.indexOf('menu3') >= 0 && !!dialogue.branch_greatgrandparent && dialogue.branch_greatgrandparent.responses.length > 0 && !!dialogue.branch_greatgrandparent.quest_text && dialogue.branch_greatgrandparent.quest_text.length > 0 )
        {
            var goodLineIndex = dialogue.branch_greatgrandparent.quest_text.length-1;
            updateResponses(dialogue.branch_greatgrandparent, goodLineIndex);
            return;
        }

        var shouldShowResponses = false;

        // set the quest ineract icon
        if( dialogue.quest_text.length > 1 && dialogue.quest_text.length-1 > questTextIndex )
        {
            interactIconElem.innerHTML = "<div style='font-size: 24px; display: inline; font-family: Arial; pointer-events: none;'>Next</div>";
        }
        else if( dialogue.hasOwnProperty('responses') && dialogue.responses.length > 0 )
        {
            shouldShowResponses = true;
            var questsIconHTML = arcadeHud.generateIconHTML(self.dialogueiconasset.getFileUrl(), 64, 64, "aaTextColorTwoColor");//"dialogueicon.png"
            interactIconElem.innerHTML = questsIconHTML;
        }
        else if( dialogue.hasOwnProperty('quest_action') )
        {
            if( dialogue.quest_action.indexOf('exit') >= 0 || dialogue.quest_action.indexOf('success') >= 0 || dialogue.quest_action.indexOf('failure') >= 0)
            {
                interactButtonElem.action = dialogue.quest_action;
                interactIconElem.innerHTML = "<div style='font-size: 24px; display: inline; font-family: Arial; pointer-events: none;'>Done</div>";
            }
            else if( dialogue.quest_action.indexOf('jump') >= 0 || dialogue.quest_action.indexOf('jump2') >= 0 || dialogue.quest_action.indexOf('jump3') >= 0 || dialogue.quest_action.indexOf('jumplite') >= 0 || dialogue.quest_action.indexOf('jumplite2') >= 0 || dialogue.quest_action.indexOf('jumplite3') >= 0 || dialogue.quest_action.indexOf('menu') >= 0 || dialogue.quest_action.indexOf('menu2') >= 0 || dialogue.quest_action.indexOf('menu3') >= 0 )
            {
                interactButtonElem.action = dialogue.quest_action;
                interactIconElem.innerHTML = "<div style='font-size: 24px; display: inline; font-family: Arial; pointer-events: none;'>OK</div>";
            }
        }
        else
        {
            interactIconElem.innerHTML = "<div style='font-size: 24px; display: inline; font-family: Arial; pointer-events: none;'>OK</div>";
        }

        if( !shouldShowResponses )
            interactButtonElem.style.pointerEvents = 'all';
        else					
            interactButtonElem.style.pointerEvents = 'none';

        questResponsesLeftElem.innerHTML = '';
        questResponsesRightElem.innerHTML = '';

        if( shouldShowResponses && dialogue.hasOwnProperty('responses') )
        {
            for( var i = 0; i < Math.round(dialogue.responses.length / 2); i++ )
                addQuestResponse(questResponsesLeftElem, dialogue.responses[i]);

            for( var i = Math.round(dialogue.responses.length / 2); i < dialogue.responses.length; i++ )
                addQuestResponse(questResponsesRightElem, dialogue.responses[i]);
        }
    }

    function showQuestDialogue(dialogue, questTextIndex_in)
    {
        var questTextIndex = (typeof questTextIndex_in === 'undefined') ? 0 : questTextIndex_in;

        // add the quest text.
        questDialogueElem.innerHTML = "";
        questDialogueElem.appendChild(document.createTextNode(dialogue.quest_text[questTextIndex]));

        //var voiceForModel = getVoiceForModel();
        var voiceForModel = {pitch: 1.0, rate: 1.0, volume: 1.0, voice: 'UK English Male'};
        if( dialogue.quest_text[questTextIndex][0] != '[' || dialogue.quest_text[questTextIndex][dialogue.quest_text[questTextIndex].length-1] != ']' )
        {
            lastSpokenText = dialogue.quest_text[questTextIndex];
            window.speechSynthesis.cancel();
            var speakText = lastSpokenText;
            speakText = speakText.replace(/d00dz/g, "dudes");
            window.speechSynthesis.speak(new SpeechSynthesisUtterance(speakText));
            //console.log('speak it: ' + dialogue.quest_text[questTextIndex]);
			//responsiveVoice.speak(dialogue.quest_text[questTextIndex], voiceForModel.voice, {pitch: voiceForModel.pitch, rate: voiceForModel.rate, volume: voiceForModel.volume});
            //aaapi.cmd('ttsspeak', dialogue.quest_text[questTextIndex], voiceForModel.voice, voiceForModel.pitch, voiceForModel.rate, voiceForModel.volume);
        }

        updateResponses(dialogue, questTextIndex);
        g_activeDialogue = dialogue;
        g_activeQuestTextIndex = questTextIndex;
    }

    //var randomDialogue = dialogues[Math.floor(Math.random() * dialogues.length)];
    var fullDialogue = parseRawDialogue(unparsedDialogue);
    processDialogueTree(fullDialogue);
    showQuestDialogue(fullDialogue, 0);

    function showTTSConfigPanel()
    {
        //if( aaapi.cmdEx('getConVarValue', 'developer') == '1' )
        if( !!modelFile && modelFile != '' )
        {
            var modelNameElem = document.querySelector("#modelName");
            modelNameElem.innerHTML = '';
            modelNameElem.appendChild(document.createTextNode(modelFile));
        }
        document.querySelector('#ttsConfig').style.display = 'none';
        document.querySelector('#ttsConfigPanel').style.display = 'table';
    }

};










































Ezquest.prototype.postInitializex = function() {
    //loadAJavaScript('https://code.responsivevoice.org/responsivevoice.js?key=lsbSYU7R', this.onReady);
    
    //document.querySelector('#application-canvas').style.display = 'none';
    document.body.innerHTML = '';
    //var div = document.createElement('div');
    //div.innerHTML = '<script src="https://code.responsivevoice.org/responsivevoice.js?key=lsbSYU7R"></script>';
    //document.body.appendChild(div);
    var script = document.createElement('script');
    script.src = 'https://code.responsivevoice.org/responsivevoice.js?key=lsbSYU7R';
    document.body.appendChild(script);
};