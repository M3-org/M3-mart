var PosterImage = pc.createScript('posterImage');

PosterImage.attributes.add('imageAsset', {type: 'asset', assetType: 'texture'});
PosterImage.attributes.add('dynamicAspectRatio', {type: 'boolean', default: true});
PosterImage.attributes.add('fixedWidth', {type: 'boolean', default: true});
PosterImage.attributes.add('fixedHeight', {type: 'boolean', default: true});
PosterImage.attributes.add('mouseHoverEntity', {type: 'entity'});

PosterImage.prototype.initialize = function() {
    var material = this.entity.render.material.clone();
    this.entity.render.material = material;
    material.diffuseMap = this.imageAsset.resource;
    material.update();

    if( this.mouseHoverEntity ) {
        this.mouseHoverEntity.on('cursor:enter', this.onCursorEnter, this);
        this.mouseHoverEntity.on('cursor:exit', this.onCursorExit, this);
    }

    if( this.dynamicAspectRatio ) {
        var originalScale = this.entity.getLocalScale().clone();
        this.originalScale = originalScale;
        
        // TODO: Support non 1:1 poster canvas w/ dynamic aspect.

        // if fixedWidth AND fixedHeight, then resize to contain
        var imageWidth = this.imageAsset.resource.width;
        var imageHeight = this.imageAsset.resource.height;
        var imageAspectRatio = imageWidth / imageHeight;
        var scale = new pc.Vec3();
        if( this.fixedWidth && this.fixedHeight ) {
            if( imageWidth > imageHeight ) {
                // shrink height
                scale.x = originalScale.x;
                scale.y = originalScale.y;
                scale.z = originalScale.z / imageAspectRatio;
            }
            else if( imageWidth < imageHeight ) {
                // shrink width
                scale.x = originalScale.x * imageAspectRatio;
                scale.y = originalScale.y;
                scale.z = originalScale.z;
            }
            else {
                // square
                scale.x = originalScale.x;
                scale.y = originalScale.y;
                scale.z = originalScale.z;
            }
        }
        else if( this.fixedWidth && !this.fixedHeight ) {
            scale.x = originalScale.x;
            scale.y = originalScale.y;
            scale.z = originalScale.z / imageAspectRatio;
        }
        else if( this.fixedHeight && !this.fixedWidth ) {
            scale.x = originalScale.x * imageAspectRatio;
            scale.y = originalScale.y;
            scale.z = originalScale.z;
        }

        this.entity.setLocalScale(scale.x, scale.y, scale.z);
    }
};

PosterImage.prototype.onCursorEnter = function(e) {
    var material = this.entity.render.material;
    material.emissiveMap = material.diffuseMap;
    material.update();
};

PosterImage.prototype.onCursorExit = function(e) {
    var material = this.entity.render.material;
    material.emissiveMap = null;
    material.update();
};