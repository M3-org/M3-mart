var Ufo = pc.createScript('ufo');

Ufo.attributes.add('target', {
    type: 'entity'
});

Ufo.attributes.add('duration', {
    type: 'number',
    default: 7
});

Ufo.attributes.add('minWait', {
    type: 'number',
    default: 12
});

Ufo.attributes.add('maxWait', {
    type: 'number',
    default: 60
});

Ufo.prototype.initialize = function() {
    this.elapsed = 0;
    this.startPos = this.entity.getPosition().clone();
    this.targetPos = this.target.getPosition().clone();
    this.state = 0;

    this.testElapsed = 0;

    this.lerpVal = new pc.Vec3();
    var waitAmount = Math.random() * (this.maxWait - this.minWait);
    this.testElapsed = this.minWait + waitAmount;
};

Ufo.prototype.fly = function() {
    this.state = 1;
    this.elapsed = 0;
    var waitAmount = Math.random() * (this.maxWait - this.minWait);
    this.testElapsed = this.minWait + waitAmount;
    this.entity.sound.play('fly');
};

Ufo.prototype.update = function(dt) {
    if( this.state != 1 ) {
        this.testElapsed -= dt;
        if( this.testElapsed <= 0 ) {
            // fly
            this.fly();
        }
        return;
    }

    this.elapsed += dt;

    var didFinish = false;
    if( this.elapsed >= this.duration ) {
        this.elapsed = this.duration;
        didFinish = true;
    }

    if( didFinish ) {
        this.entity.setPosition(this.startPos);
        this.state = 0;
    }
    else {
        var amount = this.elapsed / this.duration;
        this.lerpVal.lerp(this.startPos, this.targetPos, amount);
        this.entity.setPosition(this.lerpVal);
    }
};