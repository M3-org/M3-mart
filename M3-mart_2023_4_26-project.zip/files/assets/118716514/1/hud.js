var Hud = pc.createScript('hud');

Hud.attributes.add('css', {type: 'asset', assetType:'css', title: 'CSS Asset'});
Hud.attributes.add('html', {type: 'asset', assetType:'html', title: 'HTML Asset'});
Hud.attributes.add('buttonImage', {type: 'asset', assetType:'texture'});

Hud.prototype.initialize = function () {
    WebFont.load({
		google: {
			families: ['Roboto:300,400,700']
		}
	});
    this.app.qualitySettings = {
        preset: 'high'
    };
    if( this.app.qualitySettings.preset == 'low' ) {
        var assets = this.app.assets.filter(function (asset) {
            return asset.type == 'material';
        });

        for( var i = 0; i < assets.length; i++ ) {
            assets[i].normalMap = null;
        }
    }

    // create STYLE element
    var style = document.createElement('style');

    // append to head
    document.head.appendChild(style);
    style.innerHTML = this.css.resource || '';
    
    // Add the HTML
    this.div = document.createElement('div');
    this.div.classList.add('htmlcontainer');
    this.div.innerHTML = this.html.resource || '';
    
    // append to body
    // can be appended somewhere else
    // it is recommended to have some container element
    // to prevent iOS problems of overfloating elements off the screen
    document.body.appendChild(this.div);
    
    var ezquestContainer = this.div;//.querySelector('.ezquestContainer');
    ezquestContainer.addEventListener('mousemove', function(e) {
        e.preventDefault();
        e.stopPropagation();
        //e.stopImmediatePropagation();
    });
    ezquestContainer.addEventListener('mousedown', function(e) {
        e.preventDefault();
        e.stopPropagation();
        //e.stopImmediatePropagation();
    });
    ezquestContainer.addEventListener('mouseup', function(e) {
        e.preventDefault();
        e.stopPropagation();
        //e.stopImmediatePropagation();
    });
    ezquestContainer.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        //e.stopImmediatePropagation();
    });

    this.app.on('trophyTweet', this.doTrophyTweet, this);

    this.menuTemplateHTML = this.div.querySelector('.menuTemplate').value;
    this.fullscreenMenuHTML = this.div.querySelector('.fullscreenMenu').value;

    this.menuSlate = null;
    this.bindEvents();
    this.app.on('hud:showMenu', this.showMenu, this);
    this.app.on('hud:closeMenu', this.closeMenu, this);
    this.app.on('hud:openLink', this.openLink, this);
    this.app.on('controls:max', this.onControlsMax, this);
    this.app.on('controls:newtab', this.onControlsNewTab, this);

    //setTimeout(function() {
    //    this.app.fire('hud:showMenu', {name: 'welcome'});
   // }.bind(this), 3000);
};

Hud.prototype.bindEvents = function() {
    var self = this;
    var tweetButton = this.div.querySelector('.tweetButton');
    tweetButton.style.backgroundImage = 'url("' + this.buttonImage.getFileUrl() + '")';
    tweetButton.addEventListener('click', function() {
        self.tweet();
    });
};

Hud.prototype.openLink = function(opts) {//{entity: this.entity, href: this.href, target: this.target}
    var linkSettings = localStorage.getItem('linkSettings');
    if( linkSettings ) {
        linkSettings = JSON.parse(linkSettings);
    }
    else {
        linkSettings = [];//{href: <string>}
    }
    
    function getLinkSetting(href) {
        for( var i = 0; i < linkSettings.length; i++ ) {
            if( linkSettings[i].href == href ) {
                return linkSettings[i];
            }
        }
        return null;
    }

    var self = this;
    var linkRememberCheckbox = null;
    function launchNewTab() {
        if( opts.closeTarget ) {        
            self.app.fire('controls:close', {
                target: opts.closeTarget
            });
        }

        if( linkRememberCheckbox && linkRememberCheckbox.checked && !getLinkSetting(opts.href) ) {
            linkSettings.push({href: opts.href, method: 'newtab'});
            localStorage.setItem('linkSettings', JSON.stringify(linkSettings));
        }

        window.open(opts.href, opts.target);
    }

    function openIframe(target, url) {
        if( linkRememberCheckbox && linkRememberCheckbox.checked && !getLinkSetting(opts.href) ) {
            linkSettings.push({href: opts.href, method: 'iframe'});
            localStorage.setItem('linkSettings', JSON.stringify(linkSettings));
        }

        var didCreateIframe = false;
        var iframePlaneEntities = self.app.root.children[0].find(function (entity) {
            return entity.script && entity.script.iframePlane && entity.script.iframePlane.frameName == opts.target;
        });

        if( iframePlaneEntities.length == 1 ) {
            var iframePlaneEntity = iframePlaneEntities[0];
            var iframePlane = iframePlaneEntity.script.iframePlane;
            if( !iframePlane.iframe ) {
                // activate it
                iframePlane.activate(opts.href);
                didCreateIframe = true;
            }
            else {
                // otherwise, just set its last used url
                iframePlane.lastUsedUrl = opts.href;
                iframePlane.iframe.lastUrl = opts.href;
            }
        }

        if( !didCreateIframe ) {
            window.open(opts.href, opts.target);
        }

        return didCreateIframe;
    }

    var linkSetting = getLinkSetting(opts.href);
    if( linkSetting ) {
        if( linkSetting.method == 'newtab' ) {
            // open in new tab
            launchNewTab();
            self.closeMenu();
            return true;
        }
        else if( linkSetting.method == 'iframe' ) {
            // open in iframe
            openIframe(opts.target, opts.href);
            self.closeMenu();
            return true;
        }
        else {
            // ask
            askHow();
        }
    }
    else {
        if( this.app.qualitySettings.preset == 'verylow' || opts.target == '_blank' || opts.target == '_self' ) {
            // ask
            askHow();
        }
        else if( opts.target != '_blank' && opts.target != '_self' ) {
            // open in iframe
            openIframe(opts.target, opts.href);
            self.closeMenu();
            return true;
        }
        else {            
            // ask
            askHow();

            //self.closeMenu();
            // open in new tab
            //launchNewTab();
            //return true;
        }
    }

    function askHow() {
        var menuTemplateName = 'link';
        if( opts.hasOwnProperty('template') && opts.template ) {
            menuTemplateName = opts.template;
        }

        var menuSlate = self.showMenu({name: menuTemplateName});
        var menuLinkPreview = menuSlate.querySelector('.menuLinkPreview');
        if( menuLinkPreview ) {
            menuLinkPreview.value = opts.href;
        }
        linkRememberCheckbox = menuSlate.querySelector('.linkRememberCheckbox');

        if( opts.target != '_blank' && opts.target != '_self' && self.app.qualitySettings.preset == 'verylow' ) {
            var menuLinkIframe = menuSlate.querySelector('.menuLinkIframe');
            menuLinkIframe.parentNode.style.display = 'block';
            menuLinkIframe.addEventListener('click', function(e) {
                self.closeMenu();
                // open in iframe
                openIframe(opts.target, opts.href);
            });
        }

        var menuLinkYes = menuSlate.querySelector('.menuLinkYes');
        menuLinkYes.addEventListener('click', function(e) {
            self.closeMenu();
            // open in new tab
            launchNewTab();
        });

        if( opts.hasOwnProperty('screen') && opts.screen ) {
            var field = 'screen';
            var optValue = opts[field];
            var elems = menuSlate.querySelectorAll('.menuLinkField[field="' + field + '"]');//" field="screen" attribute="src" />')
            var elem, attribute;
            for( var i = 0; i < elems.length; i++ ) {
                elem = elems[i];
                attribute = elem.getAttribute('attribute');
                if( attribute == 'innerText' ) {
                    elem.innerHTML = '';
                    elem.appendChild(document.createTextNode(opts[field]));
                }
                else {
                    elem.setAttribute(attribute, opts[field]);
                }
            }
        }
        if( opts.hasOwnProperty('description') && opts.description ) {
            var field = 'description';
            var optValue = opts[field];
            var elems = menuSlate.querySelectorAll('.menuLinkField[field="' + field + '"]');//" field="screen" attribute="src" />')
            var elem, attribute;
            for( var i = 0; i < elems.length; i++ ) {
                elem = elems[i];
                attribute = elem.getAttribute('attribute');
                if( attribute == 'innerText' ) {
                    elem.innerHTML = '';
                    elem.appendChild(document.createTextNode(opts[field]));
                }
                else {
                    elem.setAttribute(attribute, opts[field]);
                }
            }
        }
        if( opts.hasOwnProperty('title') && opts.title ) {
            var field = 'title';
            var optValue = opts[field];
            var elems = menuSlate.querySelectorAll('.menuLinkField[field="' + field + '"]');//" field="screen" attribute="src" />')
            var elem, attribute;
            for( var i = 0; i < elems.length; i++ ) {
                elem = elems[i];
                attribute = elem.getAttribute('attribute');
                if( attribute == 'innerText' ) {
                    elem.innerHTML = '';
                    elem.appendChild(document.createTextNode(opts[field]));
                }
                else {
                    elem.setAttribute(attribute, opts[field]);
                }
            }
        }
    }
};

Hud.prototype.showMenu = function(opts) {
    this.closeMenu();

    //var canvas = document.querySelector('#application-canvas');
    //canvas.classList.add('appNoInteract');

    //this.app.timeScale = 0;
    //this.app.inputPaused = true;
    document.body.style.cursor = 'default';
    this.app.fire('pauseInput');

    var menuContentHTML = this.div.querySelector('.menuContent[name="' + opts.name + '"]').value;
    
    var menuSlate = document.createElement('div');
    menuSlate.classList.add('menuSlate');
    menuSlate.innerHTML = this.menuTemplateHTML;

    var contentContainer = menuSlate.querySelector('.menuContentContainer');
    contentContainer.innerHTML = menuContentHTML;

    var menuContainer = menuSlate.querySelector('.menuContainer');

    var self = this;
    var closeButtons = menuSlate.querySelectorAll('.closeButton');
    for( var i = 0; i < closeButtons.length; i++ ) {
        closeButtons[i].addEventListener('click', function() {
            self.app.fire('hud:closeMenu');
        });
    }

    document.body.appendChild(menuSlate);
    var tmp = menuContainer.offsetWidth;
    menuContainer.classList.add('menuContainerActive');
    //menuSlate.classList.add('menuSlateActive');

    this.menuSlate = menuSlate;
    return menuSlate;
};
/*
Pause.prototype.togglePaused = function () {
    // More information about app.timeScale http://developer.playcanvas.com/en/api/pc.Application.html#timeScale
    // app.timeScale is global and affects the value of dt that is passed into the update functions
    if (this.paused) {
        this.app.timeScale = 1;
    } else {
        this.app.timeScale = 0;
    }
    
    this.paused = !this.paused;
};*/
Hud.prototype.closeMenu = function() {
    if( !this.menuSlate ) {
        return;
    }

    this.menuSlate.remove();
    this.menuSlate = null;

    //var canvas = document.querySelector('#application-canvas');
    //canvas.classList.remove('appNoInteract');
    //this.app.timeScale = 1;
    //this.app.inputPaused = false;
    this.app.fire('unpauseInput');
};

Hud.prototype.tweet = function() {
    var text = "At the M3 merch shop, ya'll want anything while I'm here?";
    var pageUrl = 'https://m3org.com/merch';
    const tweetableText = "https://twitter.com/intent/tweet?url=" + pageUrl + "&text=" + encodeURIComponent(text);
    
    window.open(
        tweetableText,
        "twitterwindow", 
        "height=670, width=550, toolbar=0, location=0, menubar=0, directories=0,scrollbars=0"
    );
};

Hud.prototype.doTrophyTweet = function() {
    var text = "Victory! Achievement unlocked: Collected 100% of the interactive object points in @m3org #3Dstartpage";
    var pageUrl = 'https://3d.m3org.com/victory';
    const tweetableText = "https://twitter.com/intent/tweet?url=" + pageUrl + "&text=" + encodeURIComponent(text);
    
    window.open(
        tweetableText,
        "twitterwindow", 
        "height=670, width=550, toolbar=0, location=0, menubar=0, directories=0,scrollbars=0"
    );
};

Hud.prototype.onControlsNewTab = function(opts) {//{ target: this.target, href: this.href}
    //controls:newtab
    var iframe = document.querySelector('iframe[name="' + opts.target + '"]');
    if( iframe ) {
        var lastIframeUrl = iframe.lastUrl;
        //window.open(lastIframeUrl, '_blank');
        this.app.fire('hud:openLink', {target: '_blank', href: lastIframeUrl, closeTarget: opts.target});
    }
};

Hud.prototype.onControlsMax = function(opts) {//{ target: this.target}
    //controls:max
    var iframe = document.querySelector('iframe[name="' + opts.target + '"]');
    if( iframe ) {
        var self = this;
        
        //this.app.inputPaused = true;
        document.body.style.cursor = 'default';
        this.app.fire('pauseInput');
        
        var fullscreenSlate = document.createElement('div');
        fullscreenSlate.classList.add('fullscreenSlate');
        fullscreenSlate.innerHTML = this.fullscreenMenuHTML;
        document.body.appendChild(fullscreenSlate);

        iframe.oldParent = iframe.parentNode;
        var iframesContainer = iframe.parentNode;
        iframesContainer.classList.add('fullscreenActive');
        document.body.classList.add('fullscreenBodyMode');
        iframe.classList.add('fullscreenIframe');
        
        var canvas = document.querySelector('#application-canvas');
        canvas.style.display = 'none';

        var menuControlRestore = fullscreenSlate.querySelector('.menuControlRestore');
        menuControlRestore.addEventListener('click', function(e) {
            iframe.classList.remove('fullscreenIframe');
            iframe.oldParent.classList.remove('fullscreenActive');
            document.body.classList.remove('fullscreenBodyMode');
            canvas.style.display = 'block';
            fullscreenSlate.remove();
            //self.app.inputPaused = false;
            self.app.fire('unpauseInput');
        });

        var menuControlClose = fullscreenSlate.querySelector('.menuControlClose');
        menuControlClose.addEventListener('click', function(e) {
            iframe.classList.remove('fullscreenIframe');
            iframe.oldParent.classList.remove('fullscreenActive');
            document.body.classList.remove('fullscreenBodyMode');
            canvas.style.display = 'block';
            fullscreenSlate.remove();
            //self.app.inputPaused = false;
            self.app.fire('unpauseInput');
            
            self.app.fire('controls:close', {
                target: opts.target
            });
        });

        var menuControlNewTab = fullscreenSlate.querySelector('.menuControlNewTab');
        menuControlNewTab.addEventListener('click', function(e) {
            iframe.classList.remove('fullscreenIframe');
            iframe.oldParent.classList.remove('fullscreenActive');
            document.body.classList.remove('fullscreenBodyMode');
            canvas.style.display = 'block';
            fullscreenSlate.remove();
            //self.app.inputPaused = false;
            self.app.fire('unpauseInput');
            
            self.app.fire('controls:close', {
                target: opts.target
            });

            var goodUrl = iframe.lastUrl;
            if( !goodUrl ) {
                goodUrl = opt.href;
            }
            window.open(goodUrl, '_blank');
        });
    }
};